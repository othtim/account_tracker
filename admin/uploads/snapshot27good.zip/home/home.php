<?php

session_start();
	
include('includes/userfiles.php');

mysql_connect('localhost','root','shadow');
mysql_select_db('stest');

?>
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<TITLE>home</TITLE>
</HEAD>

<BODY>

<?php

if( isset( $_SESSION['username']) ){

//debug
//if(1){
	
	//pull the user data so we can tell the user when they last logged in
	$data = mysql_fetch_array( mysql_query('SELECT * FROM `users` WHERE `username` LIKE "'.$_SESSION['username'].'"'));

//	echo "Welcome back, ".$_SESSION['username'].". <BR />";
//	echo "Your last login was ".date('l, F j, Y', $data['last_seen']).". <BR />";
//	echo "<HR />";
//	echo "<a href=\"home.php\">Home</a> | <a href=\"profile.php\">Profile</a> | <a href=\"components.php\">Components</a> | <a href=\"logout.php\">Logout</a>";

include('includes/userbanner.php');
	
}


?>

















