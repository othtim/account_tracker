
<?php



?>

<a href="adminview.php"><img border="0" src="images/profile.png"> Profile</a> &nbsp; | &nbsp;&nbsp;
<a href="adminattachments.php"><img border="0" src="images/attachments.png"> Attachments</a> &nbsp; | &nbsp;&nbsp;
<a href="adminnotes.php"><img border="0" src="images/notes.png"> Notes</a> &nbsp;




<BR />

