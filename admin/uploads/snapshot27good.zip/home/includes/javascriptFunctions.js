
function getXMLHttp(){

	var pageRequest = false ;

      try {
      		pageRequest = new ActiveXObject("Msxml2.XMLHTTP");
      }
      catch (e){
         	try {
         		pageRequest = new ActiveXObject("Microsoft.XMLHTTP");
         	}
         	catch (e2){
         		pageRequest = false;
         	}
      }


	if (!pageRequest && typeof XMLHttpRequest != 'undefined')

	pageRequest = new XMLHttpRequest();

return pageRequest;
}
