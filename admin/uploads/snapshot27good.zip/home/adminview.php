<?php

include('includes/adminpostclean.php');
include('includes/adminsession.php');

include('includes/adminhtmlhead.php');
include('includes/adminbanner.php');

include('includes/adminviewheader.php');




$clientid=0;

if( isset($_SESSION['clientid']) ){
	$clientid = $_SESSION['clientid'];
	$query = sprintf("SELECT * FROM `profile` WHERE `clientid`='%s'",mysql_real_escape_string($_SESSION['clientid']));
	$result = mysql_query($query);
	$pdata = mysql_fetch_array($result);
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////


?>


<table width=70%>
<td align=right>
<a href="adminedit.php">edit</a>
</td>
</table>

<table class=table width=70%>

<tr>
	<td >
		Dealer Number: <?php echo $myclient->fields['clientdealernumber'] ?>
	</td>
	<td align=right>
		Advisor Number: <?php echo $myclient->fields['clientadvisornumber'] ?>
	</td>
</tr>

<tr>
	<td colspan=2 class=td1>

	<BR />
	
	<font size=5><?php echo $myclient->fields['clientpronoun'] ?>&nbsp;&nbsp;<?php echo $myclient->fields['clientfirstname'] ?>&nbsp;&nbsp;<?php echo $myclient->fields['clientlastname'] ?></font>
	<BR />
	<BR />
	<?php echo $myclient->fields['companyname'] ?>Company name goes here, this doesnt'e xist yet
	<BR />
	12919-90 Street, Edmonton, AB T5E3L9
	<BR />
	leftovers@gmail.com
	<BR />
	<BR />
	
	<HR />
	<font size=1>CO-INVESTOR</font>
	
	
	</td>

	<td class=td1 >

	asdasdasd
	</td>

	
</tr>



</table>






